warn 'deprecated openssl/x509 use: require "openssl" instead of "openssl/x509"'
require 'openssl'
